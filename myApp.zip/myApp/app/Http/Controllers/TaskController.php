<?php
namespace App\Http\Controllers;

use App\Http\Requests\TaskRequest;
use App\mytasks;
class TaskController extends Controller{

    public function TaskController(){
        return View::make('mytasks');
    }
	public function index()
    {
        $mytasks =mytasks::get();
        return view('mytasks.index', compact('mytasks'));
    }
	
    public function create()
    {
        return view('mytasks.create');
    }
	  public function store(TaskRequest $request)
    {
        mytasks::create($request->all());
        return redirect()->back()->with('success', 'mytasks Added');
    }
	 public function show(mytasks $mytasks)
    {
        return view('mytasks.edit', compact('mytasks'));
    }
	public function edit(mytasks $mytasks)
    {
        return view('mytasks.edit', compact('mytasks'));
    }
	  public function update(TaskRequest $request, mytasks $mytasks)
    {
        $mytasks->update($request->all());
        return redirect(route('mytasks.edit', $mytasks->id))->with('success', 'mytasks Edited');
    }
    public function destroy(mytasks $mytasks)
    {
        $mytasks->delete();
        return redirect()->back();
    }
}


?>
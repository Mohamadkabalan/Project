<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', function () {
    return redirect('/mytasks');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::group(['middleware' => 'auth'], function () {

    Route::post('/mytasks', [ 'as' =>'mytasks.store', 'uses' => 'TaskController@store']);
    Route::get('/mytasks', [ 'as' =>'mytasks.index', 'uses' => 'TaskController@index']);
    Route::get('/mytasks/create', [ 'as' =>'mytasks.create', 'uses' => 'TaskController@create']);
    Route::put('/mytasks/{mytasks}', [ 'as' =>'mytasks.update', 'uses' => 'TaskController@update']);
    Route::get('/mytasks/{mytasks}/delete', [ 'as' =>'mytasks.destroy', 'uses' => 'TaskController@destroy']);
    Route::get('/mytasks/{mytasks}/edit', [ 'as' =>'mytasks.edit', 'uses' => 'TaskController@edit']);
	});
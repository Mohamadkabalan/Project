<html>
<head>

</head>
<body>


<script src="https://unpkg.com/vue"></script>

<div id="app">
    <input type="text" id="input" v-model="message">
    <p>{{ message }}</p>
</div>

<script>
    new Vue({
        el: '#app',
        data: {
            message: 'Hello Vue.js!'
        }
    })
</script>
<script>
  
</script>
</body>
</html>



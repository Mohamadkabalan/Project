@extends('layouts.app')
@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading max-height">myTasks
                        <span class="float">
                        <a href="{{ route('myTasks.create') }}" class="btn btn-primary">Add</a>
                        </span>
                    </div>
                    <div class="panel-body">
                        <table class="table table-bordered">
                            <thead>
                            <tr>
                                <th>S.No</th>
                                <th>myTasks</th>
                                <th>Status</th>
                                <th colspan="2">Options</th>
                            </tr>
                            </thead>
                            <tbody>
                            @php $sno =1 ; @endphp
                            @foreach($myTasks as $myTasks)
                                <tr>
                                    <td>{{ $sno++ }}</td>
                                    <td>{{ $myTasks->name }}</td>
                                    <td>{{ $myTasks->status }}</td>
                                    <td><a href="{{ route('myTasks.edit', $myTasks->id) }}" class="btn btn-primary">Edit</a></td>
                                    <td><a href="{{ route('myTasks.destroy', $myTasks->id) }}" class="btn btn-danger"
                                           onclick="if(confirm('Are you want to delete')) return true; else return false;"
                                        >Delete</a></td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
